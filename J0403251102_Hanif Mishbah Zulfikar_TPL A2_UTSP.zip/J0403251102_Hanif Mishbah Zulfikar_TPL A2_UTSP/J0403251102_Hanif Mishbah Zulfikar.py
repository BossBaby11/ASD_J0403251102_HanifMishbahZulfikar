# ==============================================================================
# UJIAN TENGAH PRAKTIKUM - ALGORITMA & STRUKTUR DATA (TPL2106)
# Nama    : Hanif Mishbah Zulfikar
# NIM     : J0403251102
# Kelas   : TPL A/P2
# ==============================================================================

# 1. FILE HANDLING & DICTIONARY (Sub-CPMK 1) [cite: 31]
def muat_data_buku(nama_file):
    """
    Fungsi untuk membaca 'buku.txt' dan menyimpannya ke Dictionary.
    Format file: kode_buku,judul,harga
    """
    database_buku = {} # Inisialisasi dictionary untuk menyimpan data buku
    with open(nama_file, 'r', encoding='utf-8') as file: # Membuka file dengan mode baca dan encoding UTF-8
        for line in file: # Iterasi setiap baris dalam file
            kode, judul, harga = line.strip().split(',') # Memisahkan kode, judul, dan harga berdasarkan koma
            database_buku[kode] = { # Menyimpan data buku dalam dictionary dengan kode sebagai key
                'judul': judul,
                'harga': int(harga)
            }
    return database_buku # Mengembalikan dictionary yang berisi data buku

# 2. LINKED LIST - MANAJEMEN PROMOSI (Sub-CPMK 2) [cite: 32]
class Node:
    def __init__(self, judul): # Konstruktor untuk inisialisasi node dengan judul buku
        self.data = judul # Menyimpan judul buku dalam atribut data
        self.next = None # Inisialisasi atribut next untuk menunjuk ke node berikutnya, awalnya None

class LinkedListPromosi: 
    def __init__(self): # Konstruktor untuk inisialisasi linked list dengan head awalnya None
         self.head = None

    def tambah_buku_promosi(self, judul): # Menambahkan buku ke daftar promosi (Linked List) 
        """Menambahkan buku ke daftar promosi (Linked List)"""
        node_baru = Node(judul) # Membuat node baru dengan judul buku yang diberikan
        if self.head is None: # Jika linked list masih kosong, set head ke node baru
            self.head = node_baru # Menetapkan node baru sebagai head dari linked list
        else: # Jika linked list tidak kosong, cari node terakhir dan tambahkan node baru di akhir
            current = self.head # Mulai dari head untuk mencari node terakhir
            while current.next is not None: # Iterasi hingga menemukan node terakhir (node yang next-nya None)
                current = current.next # Pindah ke node berikutnya
            current.next = node_baru # Menetapkan node baru sebagai next dari node terakhir
        print(f"Buku '{judul}' ditambahkan ke daftar promosi.") # Menampilkan pesan bahwa buku telah ditambahkan ke daftar promosi

    def tampilkan_promosi(self):
        """Menampilkan semua buku dalam daftar promosi"""
        if self.head is None: # Jika linked list kosong, tampilkan pesan bahwa daftar promosi kosong
            print("Daftar promosi kosong.")
            return
        print("\nDaftar Buku Promosi:") # Menampilkan header untuk daftar buku promosi
        current = self.head # Mulai dari head untuk menampilkan semua buku dalam linked list
        nomor = 1 # Inisialisasi nomor untuk penomoran buku dalam daftar promosi
        while current is not None: # Iterasi hingga mencapai akhir linked list
            print(f"  {nomor}. {current.data}") # Menampilkan nomor dan judul buku saat ini
            current = current.next # Pindah ke node berikutnya
            nomor += 1 # Increment nomor untuk buku berikutnya dalam daftar promosi

# 3. QUEUE - ANTIREAN KASIR (Sub-CPMK 3) [cite: 33]
class AntreanKasir:
    def __init__(self): 
        self.antrean = [] # Inisialisasi list untuk menyimpan antrean pelanggan

    def tambah_antrean(self, nama_pelanggan): 
        """Menambah antrean (Enqueue)"""
        self.antrean.append(nama_pelanggan) # Menambahkan nama pelanggan ke akhir list antrean
        print(f"Pelanggan '{nama_pelanggan}' masuk ke antrean.") # Menampilkan pesan bahwa pelanggan telah masuk ke antrean
        print(f"Antrean saat ini: {self.antrean}") # Menampilkan antrean saat ini setelah penambahan pelanggan

    def layani_pelanggan(self):
        """Menghapus antrean (Dequeue)"""
        if len(self.antrean) == 0: # Jika antrean kosong, tampilkan pesan bahwa tidak ada pelanggan yang dilayani
            print("Antrean kosong, tidak ada pelanggan yang dilayani.") 
            return None
        pelanggan = self.antrean.pop(0) # Menghapus dan mendapatkan nama pelanggan pertama dalam antrean (FIFO)
        print(f"Melayani pelanggan: '{pelanggan}'") # Menampilkan pesan bahwa pelanggan sedang dilayani
        print(f"Antrean saat ini: {self.antrean}")  # Menampilkan antrean saat ini setelah pelanggan dilayani
        return pelanggan # Mengembalikan nama pelanggan yang dilayani

# 4. SORTING - LAPORAN TRANSAKSI (Sub-CPMK 4) [cite: 34]
def urutkan_transaksi(list_harga): 
    """ 
    Mengurutkan list harga secara manual menggunakan 
    Insertion Sort atau Merge Sort.
    """
    ##Menggunakan Insertion Sort untuk mengurutkan list harga secara manual
    for index in range(1, len(list_harga)): # Iterasi mulai dari indeks 1 hingga akhir list harga
        currentvalue = list_harga[index] # Menyimpan nilai saat ini yang akan dibandingkan dengan elemen sebelumnya
        position = index # Menyimpan posisi saat ini untuk penempatan nilai yang benar setelah perbandingan
        while position > 0 and list_harga[position - 1] > currentvalue: # Perbandingan dengan elemen sebelumnya, jika elemen sebelumnya lebih besar, geser elemen tersebut ke kanan
            list_harga[position] = list_harga[position - 1] # Geser elemen sebelumnya ke posisi saat ini
            position = position - 1  # Pindah ke posisi sebelumnya untuk melanjutkan perbandingan
        list_harga[position] = currentvalue # Setelah menemukan posisi yang benar, tempatkan nilai saat ini di posisi tersebut
    return list_harga # Mengembalikan list harga yang telah diurutkan

# ==============================================================================
# MAIN PROGRAM - MENU ANTARMUKA
# ==============================================================================
def main():
    # Inisialisasi Data
    file_db = "./J0403251102_Hanif Mishbah Zulfikar_TPL A2_UTSP/buku.txt" # Menentukan nama file untuk database buku
    data_buku = muat_data_buku(file_db) # Memuat data buku dari file dan menyimpannya dalam dictionary
    list_promosi = LinkedListPromosi() # Membuat instance LinkedListPromosi untuk mengelola daftar promosi buku
    antrean_toko = AntreanKasir() # Membuat instance AntreanKasir untuk mengelola antrean kasir
    riwayat_transaksi = [150000, 50000, 200000, 75000, 120000] # Contoh data harga transaksi untuk laporan penjualan

    while True: # Loop utama untuk menampilkan menu dan menangani pilihan pengguna
        print("\n--- SISTEM MANAJEMEN TOKO BUKU ---")
        print("1. Lihat Katalog Buku (Dictionary/File)")
        print("2. Kelola Daftar Promosi (Linked List)")
        print("3. Kelola Antrean Kasir (Queue)")
        print("4. Lihat Laporan Penjualan Terurut (Sorting)")
        print("5. Keluar")
        
        pilihan = input("Pilih menu (1-5): ") # Meminta input pilihan menu dari pengguna

        if pilihan == '1': # Jika pengguna memilih opsi 1, tampilkan katalog buku yang telah dimuat dari file
            print("\nKatalog Buku:", data_buku)
        
        elif pilihan == '2': 
            judul_baru = input("Masukkan judul buku untuk promosi: ")
            list_promosi.tambah_buku_promosi(judul_baru)
            list_promosi.tampilkan_promosi()

        elif pilihan == '3': # Jika pengguna memilih opsi 3, tampilkan submenu untuk mengelola antrean kasir
            print("\n--- ANTREAN KASIR ---")
            print("1. Tambah Antrean")
            print("2. Layani Pelanggan")
            input_pilihan = input("Pilih opsi (1-2): ")
            if input_pilihan == '1': # Jika pengguna memilih opsi 1, minta nama pelanggan dan tambahkan ke antrean kasir
                nama = input("Nama Pelanggan: ")
                antrean_toko.tambah_antrean(nama)
            elif input_pilihan == '2': # Jika pengguna memilih opsi 2, layani pelanggan pertama dalam antrean kasir
                antrean_toko.layani_pelanggan()

        elif pilihan == '4': # Jika pengguna memilih opsi 4, tampilkan laporan penjualan yang telah diurutkan berdasarkan harga transaksi
            print("Harga Sebelum Urut:", riwayat_transaksi)
            hasil_sort = urutkan_transaksi(riwayat_transaksi)
            print("Harga Sesudah Urut:", hasil_sort)

        elif pilihan == '5': # Jika pengguna memilih opsi 5, keluar dari program
            print("Program selesai. Terima kasih.")
            break
        else: 
            print("Pilihan tidak valid!")

if __name__ == "__main__":
    main() # Menjalankan fungsi main untuk memulai program ketika file ini dieksekusi langsung